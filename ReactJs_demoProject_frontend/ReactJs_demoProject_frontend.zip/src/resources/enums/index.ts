enum ActionType {
    LOGIN = "LOGIN",  
    LOGOUT = "LOGOUT",  
 
    UPDATE_PROFILE = "UPDATE_PROFILE", 
 
  }
  
  export default ActionType;
  