
import './components.css';
 

function Dashboard() {
  return (
    <div>
      
      <img src="https://www.google.com/images/branding/googlelogo/1x/googlelogo_color_272x92dp.png" alt="google" />
      <h1>Dashboard</h1>
      
    </div>
  )
}

export default Dashboard
