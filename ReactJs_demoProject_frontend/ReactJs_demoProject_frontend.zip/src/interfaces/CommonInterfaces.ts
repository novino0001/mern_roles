
export interface UserData {
    userId : string;
    fullName: string; 
    email: string; 
    token : string;
    role: string;
   
}
  