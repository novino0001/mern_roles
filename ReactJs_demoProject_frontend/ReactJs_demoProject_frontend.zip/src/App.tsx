 
import './App.css';
import PublicRoutes from './PublicRoutes';
 
 function App() {
  return (
    <div className="App">
    <PublicRoutes/>
 
    </div>
  );
}

export default App;
